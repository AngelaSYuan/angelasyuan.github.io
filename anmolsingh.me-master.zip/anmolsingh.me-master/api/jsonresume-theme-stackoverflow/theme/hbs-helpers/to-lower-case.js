
module.exports = {
  toLowerCase: str => str.toLowerCase()
};
