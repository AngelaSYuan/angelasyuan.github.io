module.exports = {
  spaceToDash: str => str.replace(/\s/g, '-').toLowerCase()
};
