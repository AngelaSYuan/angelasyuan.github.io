---
title: 'Hi, my name is'
name: 'Anmol Singh'
subtitle: 'I build things on web.'
buttonText: 'Get In Touch'
---

I'm a software engineer based in Banglore, India specializing in building (and occasionally designing) exceptional websites, applications, and everything in between.
