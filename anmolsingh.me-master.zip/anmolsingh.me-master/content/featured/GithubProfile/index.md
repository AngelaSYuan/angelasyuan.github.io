---
date: '2'
title: 'Github Profile Readme'
cover: './demo.png'
github: 'https://github.com/anmol098/anmol098'
external: 'https://github.com/anmol098'
tech:
  - Markdown
  - Github Actions
showInProjects: true
---

You found a secret! anmol098/anmol098 is a ✨special ✨ repository that you can use to add a README.md to your GitHub profile.
