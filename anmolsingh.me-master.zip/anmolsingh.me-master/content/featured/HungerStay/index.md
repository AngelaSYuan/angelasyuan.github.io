---
date: '1'
title: 'HungerStay'
cover: './Hungerstay.png'
github: ''
external: 'https://www.figma.com/proto/S0F2VpuHWHCuYLVO0XpXR1/HungerStay-Web?node-id=2%3A42&scaling=min-zoom'
tech:
  - Vue.js
  - Flutter
  - Node.js
  - MySql
showInProjects: true
---

HungerStay is a contactless food ordering app available for mobile. Users can scan the HungerStay QR and place an order by viewing the restaurant menu. The project includes mobile and web app for users and a CRM dashboard for restaurants Successfully sold it to some restaurants but failed to optimize the sales process in time and also COVID outbreak & big brands like paytm & zomato emerging as a competition.
