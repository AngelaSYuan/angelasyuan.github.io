---
date: '2020-03-02'
title: 'Software Engineer'
company: 'ClearTax'
location: 'Banglore, India'
range: 'March 2020 - Present'
url: 'https://www.cleartax.in/'
---

- Write modern, performant, maintainable code for a diverse array of client and internal projects
- Developed in-house airline module for claiming input tax credits and helping company to save up to ₹10 LPA on recurring basis.
- Developed Oracle NetSuite Connector to ingest ERP data to our server for easy filing of GST returns and thus boost the product reach by 20% across India.
