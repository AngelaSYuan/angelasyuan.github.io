---
date: '2020-06-01'
title: 'Airline Travel Credit'
github: ''
external: ''
tech:
  - Pdf-Parser
  - NodeJs
company: 'ClearTax'
showInProjects: true
---

In-house airline module for claiming input tax credits on flight tickets and helping company to save up to ₹10 LPA on recurring basis.
