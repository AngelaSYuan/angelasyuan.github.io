---
date: '2017-09-01'
title: 'Learn C++'
github: ''
external: ''
android: 'https://play.google.com/store/apps/details?id=com.learning.learncpp'
tech:
  - java
  - XML
company: ''
showInProjects: false
---

My second android app. this app contains basics of C++ programming language
