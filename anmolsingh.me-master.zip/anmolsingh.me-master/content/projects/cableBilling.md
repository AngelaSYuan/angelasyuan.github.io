---
date: '2019-01-01'
title: 'Cable Billing Software'
github: ''
external: 'https://www.aapreneur.com/cable/'
android: 'https://play.google.com/store/apps/details?id=com.aapreneur.cablemanagment'
ios: ''
tech:
  - PHP
  - HTML
  - Java
  - MySql
company: ''
showInProjects: true
---

Billing software for cable operators for hassle-free billings of their costumer's. Currently serving many cable operators and with a database of more than 20,000 costumers The software includes an mobile app for billings and a web dashboard for operators.
