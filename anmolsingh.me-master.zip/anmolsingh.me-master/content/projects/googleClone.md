---
date: '2020-08-24'
title: 'Google Search Clone'
github: 'https://github.com/anmol098/Google-Clone'
external: 'https://google-clone-smoky.vercel.app/'
tech:
  - Vue
  - Bulma CSS
showInProjects: true
---

A simple Google Search Clone this the Day 1 of the 15 Days of development. Revised Several Topics of VueJs
