---
date: '2017-05-01'
title: 'Learn C '
github: ''
external: ''
android: 'https://play.google.com/store/apps/details?id=com.learning.learnc'
tech:
  - java
  - XML
company: ''
showInProjects: false
---

My very first android app. this app contains basics of C programming language
