---
date: '2020-08-25'
title: 'Tinder Clone'
github: 'https://github.com/anmol098/tinder-clone'
external: 'https://tinder-clone.vercel.app/'
tech:
  - Vue
  - Vuetify
showInProjects: true
---

A simple Tinder Clone to develop swiping card view this the Day 2 of the 15 Days of development. Revised Several Topics of VueJs and learned basics of CSS.
