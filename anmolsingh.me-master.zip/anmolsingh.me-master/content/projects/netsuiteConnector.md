---
date: '2020-05-01'
title: 'Oracle NetSuite Connector'
github: ''
external: ''
tech:
  - Suitescript
  - NetSuite ERP
  - XML
company: 'ClearTax'
showInProjects: true
---

Developed NetSuite Connector For ClearTax in this all the Invoice level ERP data is sent to ClearTax for easy filing of the GST returns
