---
title: 'Connect With me as a true Web Developer'
buttonText: 'npx anmol'
---

👇just hit this in your terminal with npm installed👇

I am currently looking for new opportunities, my inbox is always open. Whether you have a question or just want to say hi, I will try my best to get back to you!
